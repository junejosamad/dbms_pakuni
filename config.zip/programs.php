<?php
require_once 'config/session.php';
require_once 'university-dashboard-functions.php';

// Check if user is logged in and is a university
require_auth();
require_role('university');

// Debug information
error_log("User ID: " . $_SESSION['user_id']);
error_log("User Role: " . $_SESSION['user_role']);

// Initialize dashboard
$dashboard = new UniversityDashboard($_SESSION['user_id']);

// Debug university ID
$university_id = $dashboard->getUniversityId();
error_log("University ID: " . ($university_id ?? 'null'));

// Get university programs
$programs = $dashboard->getUniversityPrograms() ?? [];
error_log("Number of programs found: " . count($programs));

// Get user information from session
$user_name = $_SESSION['user_name'] ?? 'University Representative';
$university_info = $dashboard->getUniversityInfo();
if (!$university_info) {
    $university_info = [
        'name' => 'Your University',
        'representative_name' => $user_name
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Programs - PakUni</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="css/university-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .programs-container {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .program-filters {
            display: flex;
            gap: 15px;
        }

        .program-filters select,
        .program-filters input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            min-width: 200px;
        }

        .add-program-btn {
            padding: 10px 20px;
            background: #2196F3;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.3s;
        }

        .add-program-btn:hover {
            background: #1976D2;
        }

        .program-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }

        .program-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .program-header {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #eee;
        }

        .program-header h3 {
            margin: 0;
            color: #333;
            font-size: 1.2em;
        }

        .program-header p {
            margin: 5px 0 0;
            color: #666;
            font-size: 0.9em;
        }

        .program-details {
            padding: 20px;
        }

        .program-info {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #666;
        }

        .info-item i {
            width: 20px;
            color: #2196F3;
        }

        .program-status {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.9em;
            margin-top: 10px;
        }

        .program-status.active {
            background: #d4edda;
            color: #155724;
        }

        .program-status.inactive {
            background: #f8d7da;
            color: #721c24;
        }

        .program-actions {
            padding: 15px 20px;
            background: #f8f9fa;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .edit-program,
        .delete-program {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.3s;
        }

        .edit-program {
            background: #2196F3;
            color: white;
        }

        .edit-program:hover {
            background: #1976D2;
        }

        .delete-program {
            background: #dc3545;
            color: white;
        }

        .delete-program:hover {
            background: #c82333;
        }

        .no-programs {
            text-align: center;
            padding: 40px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 20px;
        }

        .no-programs i {
            font-size: 48px;
            color: #ccc;
            margin-bottom: 15px;
        }

        .no-programs p {
            color: #666;
            font-size: 1.1em;
            margin: 0;
        }

        .success-message {
            background: #4CAF50;
            color: white;
            padding: 8px 15px;
            border-radius: 4px;
            margin-top: 10px;
            animation: fadeOut 3s forwards;
        }

        @keyframes fadeOut {
            0% { opacity: 1; }
            70% { opacity: 1; }
            100% { opacity: 0; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <h1>PakUni</h1>
        </div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="universities.php">Universities</a></li>
            <li><a href="university-dashboard.php">Dashboard</a></li>
            <li><a href="logout.php" class="btn-login">Logout</a></li>
        </ul>
    </nav>

    <div class="dashboard-container">
        <aside class="sidebar">
            <div class="user-profile">
                <img src="https://via.placeholder.com/100" alt="Profile Picture" class="profile-pic">
                <h3><?php echo htmlspecialchars($user_name); ?></h3>
                <p>University Representative</p>
                <p class="university-name"><?php echo htmlspecialchars($university_info['name']); ?></p>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="university-dashboard.php"><i class="fas fa-home"></i> Overview</a></li>
                    <li><a href="applications.php"><i class="fas fa-file-alt"></i> Applications</a></li>
                    <li><a href="document-verification.php"><i class="fas fa-file-upload"></i> Document Verification</a></li>
                    <li><a href="deadlines.php"><i class="fas fa-calendar"></i> Manage Deadlines</a></li>
                    <li><a href="programs.php" class="active"><i class="fas fa-graduation-cap"></i> Programs</a></li>
                    <li><a href="university-profile.php"><i class="fas fa-university"></i> University Profile</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                </ul>
            </nav>
        </aside>

        <main class="programs-container">
            <div class="page-header">
                <h2>University Programs</h2>
                <div class="program-filters">
                    <select id="program-level">
                        <option value="all">All Levels</option>
                        <option value="undergraduate">Undergraduate</option>
                        <option value="graduate">Graduate</option>
                        <option value="phd">PhD</option>
                    </select>
                    <input type="text" placeholder="Search programs..." id="program-search">
                    <button class="add-program-btn">
                        <i class="fas fa-plus"></i> Add Program
                    </button>
                </div>
            </div>

            <div class="program-list">
                <?php if (empty($programs)): ?>
                    <div class="no-programs">
                        <i class="fas fa-graduation-cap"></i>
                        <p>No programs found</p>
                    </div>
                <?php else: 
                    foreach ($programs as $program): 
                ?>
                    <div class="program-card" data-program-id="<?php echo $program['id']; ?>" data-level="<?php echo strtolower($program['degree_type']); ?>">
                        <div class="program-header">
                            <h3><?php echo htmlspecialchars($program['name']); ?></h3>
                            <p><?php echo htmlspecialchars($program['degree_type']); ?></p>
                        </div>
                        <div class="program-details">
                            <p><strong>Duration:</strong> <?php echo htmlspecialchars($program['duration']); ?></p>
                            <p><strong>Admission Deadline:</strong> <?php echo date('F j, Y', strtotime($program['admission_deadline'])); ?></p>
                            <?php if (!empty($program['description'])): ?>
                                <p><strong>Description:</strong> <?php echo htmlspecialchars($program['description']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($program['requirements'])): ?>
                                <p><strong>Requirements:</strong> <?php echo htmlspecialchars($program['requirements']); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="program-actions">
                            <a href="edit_program.php?id=<?php echo $program['id']; ?>" class="edit-btn">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <button class="delete-btn" data-program-id="<?php echo $program['id']; ?>">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                <?php endforeach;
                endif; ?>
            </div>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const programLevel = document.getElementById('program-level');
            const programSearch = document.getElementById('program-search');
            const programList = document.querySelector('.program-list');

            // Filter programs based on level and search
            function filterPrograms() {
                const level = programLevel.value;
                const search = programSearch.value.toLowerCase();
                const programs = programList.querySelectorAll('.program-card');

                programs.forEach(program => {
                    const programName = program.querySelector('.program-header h3').textContent.toLowerCase();
                    const programLevel = program.getAttribute('data-level');
                    
                    const levelMatch = level === 'all' || programLevel === level;
                    const searchMatch = programName.includes(search);

                    program.style.display = levelMatch && searchMatch ? 'block' : 'none';
                });
            }

            programLevel.addEventListener('change', filterPrograms);
            programSearch.addEventListener('input', filterPrograms);

            // Program actions
            programList.addEventListener('click', async (e) => {
                const editBtn = e.target.closest('.edit-btn');
                const deleteBtn = e.target.closest('.delete-btn');
                
                if (editBtn || deleteBtn) {
                    const programCard = e.target.closest('.program-card');
                    const programId = programCard.getAttribute('data-program-id');

                    if (editBtn) {
                        // Redirect to edit program page
                        window.location.href = `edit_program.php?id=${programId}`;
                    } else if (deleteBtn) {
                        if (confirm('Are you sure you want to delete this program?')) {
                            try {
                                const response = await fetch('delete_program.php', {
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                    },
                                    body: JSON.stringify({
                                        program_id: programId
                                    })
                                });

                                if (response.ok) {
                                    programCard.remove();
                                    
                                    // Show success message
                                    const message = document.createElement('div');
                                    message.className = 'success-message';
                                    message.textContent = 'Program deleted successfully';
                                    programList.insertBefore(message, programList.firstChild);
                                    
                                    setTimeout(() => message.remove(), 3000);

                                    // If no programs left, show no programs message
                                    if (programList.querySelectorAll('.program-card').length === 0) {
                                        programList.innerHTML = `
                                            <div class="no-programs">
                                                <i class="fas fa-graduation-cap"></i>
                                                <p>No programs found</p>
                                            </div>
                                        `;
                                    }
                                }
                            } catch (error) {
                                console.error('Error deleting program:', error);
                            }
                        }
                    }
                }
            });

            // Add program button
            const addProgramBtn = document.querySelector('.add-program-btn');
            addProgramBtn.addEventListener('click', () => {
                console.log('Add Program button clicked');
                try {
                    window.location.href = 'add_program.php';
                } catch (error) {
                    console.error('Error navigating to add program page:', error);
                }
            });
        });
    </script>
</body>
</html> 