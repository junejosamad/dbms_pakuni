<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<nav class="navbar">
    <div class="navbar-brand">
        <a href="index.php">PakUni</a>
    </div>
    <div class="navbar-menu">
        <?php if (is_authenticated()): ?>
            <div class="navbar-end">
                <div class="navbar-item">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></span>
                </div>
                <div class="navbar-item">
                    <a href="logout.php" class="button is-light">Logout</a>
                </div>
            </div>
        <?php else: ?>
            <div class="navbar-end">
                <div class="navbar-item">
                    <a href="login.php" class="button is-light">Login</a>
                </div>
                <div class="navbar-item">
                    <a href="register.php" class="button is-primary">Register</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</nav> 