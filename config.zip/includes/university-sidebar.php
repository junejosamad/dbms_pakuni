            <li><a href="programs.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'programs.php' ? 'active' : ''; ?>">
                <i class="fas fa-graduation-cap"></i> Programs
            </a></li>
            <li><a href="university-profiles.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'university-profiles.php' ? 'active' : ''; ?>">
                <i class="fas fa-university"></i> University Profiles
            </a></li> 